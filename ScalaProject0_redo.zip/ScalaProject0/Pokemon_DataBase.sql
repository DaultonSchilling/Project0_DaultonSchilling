DROP DATABASE IF EXISTS Pokemon_DataBase;
CREATE DATABASE Pokemon_DataBase;

Use Pokemon_DataBase;

CREATE TABLE Main 
(
	PokemonID							int					NOT NULL,
	PokemonName							nvarchar(100)		NOT NULL,
	PokemonTypeID                     	int					NOT NULL,
	PokemonType2ID						int				    NOT NULL,
	PokemonGenerationID					int					NOT NULL,
	Evolves								bit				    NOT NULL  DEFAULT 0,
	
	CONSTRAINT pk_PokemonID PRIMARY KEY(PokemonID ASC)
    
    #CONSTRAINT fk_PokemonType_PokemonTypeID FOREIGN KEY(PokemonTypeID)
	#REFERENCES PokemonType(PokemonTypeID),
    
    #CONSTRAINT fk_PokemonGeneration_PokemonGenerationID FOREIGN KEY(PokemonGenerationID)
	#REFERENCES PokemonGeneration(PokemonGenerationID) 
    
    
	

);

CREATE TABLE Pokemon_Generation 
(
	PokemonGenerationID						int					NOT NULL,
	PokemonRegionName						nvarchar(100)		NOT NULL,
	
	
	CONSTRAINT pk_PokemonGenerationID PRIMARY KEY(PokemonGenerationID ASC)

);

CREATE TABLE Pokemon_Type 
(
	PokemonTypeID							int					NOT NULL,
	PokemonType								nvarchar(100)		NOT NULL,
	
	
	CONSTRAINT pk_PokemonTypeID PRIMARY KEY(PokemonTypeID ASC)
	
);




INSERT INTO Main (PokemonID, PokemonName , PokemonTypeID, PokemonType2ID, PokemonGenerationID, Evolves)
VALUES 
(1, "Bulbasaur", 4, 8, 1, 1),
(2, "Ivysaur", 4, 8, 1, 1),
(3, "Venusaur", 4, 8, 1, 0),
(4, "Charmander", 2, 0, 1, 1),
(5, "Charmeleon", 2, 0, 1, 1),
(6, "Charizard", 2, 10, 1, 0),
(7, "Squirtle", 3, 0, 1, 1),
(8, "Wartortle", 3, 0, 1, 1),
(9, "Blastoise", 3, 0, 1, 0);







INSERT INTO Pokemon_Type  
		(PokemonTypeID, PokemonType)
VALUES 
(0, "None"),
(1, "Normal"),
(2, "Fire"),
(3, "Water"),
(4, "Grass"),
(5, "Electric"),
(6, "Ice"),
(7, "Fighting"),
(8, "Poison"),
(9, "Ground"),
(10, "Flying"),
(11, "Psychic"),
(12, "Bug"),
(13, "Rock"),
(14, "Ghost"),
(15, "Dark"),
(16, "Dragon"),
(17, "Steel"),
(18, "Fairy");

INSERT INTO Pokemon_Generation
		(PokemonGenerationID, PokemonRegionName)
VALUES 
(1, "Kanto"),
(2, "Johto"),
(3, "Hoenn"),
(4, "Sinnoh"),
(5, "Unova"),
(6, "Kalos"),
(7, "Alola"),
(8, "Galar");



SELECT * FROM Main;

SELECT * FROM Pokemon_Generation;

SELECT * FROM Pokemon_Type;

DELETE FROM Main WHERE PokemonID = 'ID';

UPDATE Main SET PokemonID = 'newid', PokemonName = 'name', PokemonTypeID = 'typeid', PokemonType2ID = 'type2id', PokemonGenerationID = 'genid', Evolves = 'evolves' WHERE PokemonID = 'old';




