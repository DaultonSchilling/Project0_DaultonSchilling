import java.sql.DriverManager
import java.sql.Connection
import java.util.Scanner
import java.io.PrintWriter
import java.io.File
import java.util.Calendar


object MainClass
{

    def main(args: Array[String]):Unit = 
    {
//********************************************************************************
    // connect to the database named "mysql" on the localhost
    val driver = "com.mysql.cj.jdbc.Driver"
    // Modify for whatever port you are running your DB on
    val url = "jdbc:mysql://localhost:3306/Pokemon_DataBase" 
    val username = "root"
    val password = "jared24" 
    val log = new PrintWriter(new File("query.log"))

    var connection:Connection = null
//********************************************************************************

    def DisplayAllPokemon: Unit = 
    {
        try 
        {
            Class.forName(driver)
            connection = DriverManager.getConnection(url, username, password)
     
            val statement = connection.createStatement()
            val resultSet = statement.executeQuery("SELECT * FROM Main") 
            log.write(Calendar.getInstance().getTimeInMillis + " - Excecuting 'SELECT * FROM Main'\n")
      
            while ( resultSet.next() )
            {
                 print(resultSet.getInt(1) + " " + resultSet.getString(2))
                 println()
            }

        } 
        catch 
        {
            case e: Exception => e.printStackTrace
            log.write("Error! "+ e.getMessage())
        }
        connection.close()
       
    }

    def DisplayAllRegions_Generations: Unit = 
    {
        try 
        {
            Class.forName(driver)
            connection = DriverManager.getConnection(url, username, password)
     
            val statement = connection.createStatement()
            val resultSet = statement.executeQuery("SELECT * FROM Pokemon_Generation") 
            log.write(Calendar.getInstance().getTimeInMillis + " - Excecuting 'SELECT * FROM Pokemon_Generation'\n")
      
            while ( resultSet.next() )
            {
                 print(resultSet.getInt(1) + " " + resultSet.getString(2))
                 println()
            }

        } 
        catch 
        {
            case e: Exception => e.printStackTrace
            log.write("Error! "+ e.getMessage())
        }
        connection.close()
         
    }

    def DisplayAllTypes: Unit = 
    {
        try 
        {
            Class.forName(driver)
            connection = DriverManager.getConnection(url, username, password)
     
            val statement = connection.createStatement()
            val resultSet = statement.executeQuery("SELECT * FROM Pokemon_Type;") 
            log.write(Calendar.getInstance().getTimeInMillis + " - Excecuting 'SELECT * FROM Pokemon_Type;'\n")
      
            while ( resultSet.next() )
            {
                 print(resultSet.getInt(1) + " " + resultSet.getString(2))
                 println()
            }

        } 
        catch 
        {
            case e: Exception => e.printStackTrace
            log.write("Error! "+ e.getMessage())
        }
        connection.close()
          
         
    }


    def AddPokemon(a: Int, b: String,c: Int,d: Int,e: Int, f:Boolean) 
    {
        Class.forName(driver)
        connection = DriverManager.getConnection(url, username, password)
     
           var id = a
           var name = b
           var typeid = c
           var type2id = d
           var genid = e
           var evolves = f

        val statement = connection.createStatement()
        val resultSet = statement.executeUpdate("INSERT INTO Main (PokemonID, PokemonName , PokemonTypeID, PokemonType2ID, PokemonGenerationID, Evolves)" +
                     "VALUES(" + id + ","  + "'" + name + "'" +"," + typeid + ","  + type2id + "," + genid + "," + evolves + ");") 
        log.write(Calendar.getInstance().getTimeInMillis + " - Excecuting 'INSERT INTO Main '\n")
        connection.close()
        
    }

    def RemovePokemon(a: Int) 
    {
        Class.forName(driver)
        connection = DriverManager.getConnection(url, username, password)
     
        var ID = a

        val statement = connection.createStatement()
        val resultSet = statement.executeUpdate("DELETE FROM Main WHERE PokemonID =" + "'" + ID + "'" + ";")
        log.write(Calendar.getInstance().getTimeInMillis + " - Excecuting 'DELETE FROM Main WHERE PokemonID = 'ID'; '\n")
        connection.close()
        
    }

    def UpdatePokemon(OldID: Int, a: Int, b: String, c: Int, d: Int, e: Int, f: Boolean) 
    {
        Class.forName(driver)
        connection = DriverManager.getConnection(url, username, password)

           var old = OldID
           var newid = a
           var name = b
           var typeid = c
           var type2id = d
           var genid = e
           var evolves = f

        val statement = connection.createStatement()
        
        val resultSet = statement.executeUpdate(
        "UPDATE Main SET "+ "PokemonID = " + newid + ", " + "PokemonName = " + "'" + name + "'" + "," + "PokemonTypeID = " + typeid + ", " + "PokemonType2ID = " + type2id + ", " + "PokemonGenerationID = " + genid + ", " + "Evolves = " + evolves + " WHERE PokemonID = " + old + ";")
        log.write(Calendar.getInstance().getTimeInMillis + " - Excecuting 'UPDATE Main SET PokemonID'; '\n")
        connection.close()
        
    }




//********************************************************************************



        var input_Main = ""
        println("**************************")
        println("Welcome to the Pokedex! ")
        
        def Home: Unit =
        {

             println("1) View Pokedex")
             println("2) Enter Administrator Menu")
             println("3) Exit the Pokdex")

             println("**************************")

             input_Main = scala.io.StdIn.readLine()
        
             Handler
        }
        
        
        Home
        
       

        def Handler: Unit =
        {
                
                if(input_Main.equalsIgnoreCase("1"))//*********************************MAIN MENU OPTION***********************
                {
                  

                   println("   A) View by Type")
                   println("   B) View by Region/Generation")
                   println("   E) Go Home")
                        
                  
                    DisplayAllPokemon
                    println("**************************")
                    var input2 = ""
                    input2 = scala.io.StdIn.readLine()

                    if(input2.equalsIgnoreCase("a"))//***********************TYPE SUB-MENU*********************
                    {
                         DisplayAllTypes
                         println("**************************")
                         input2 = scala.io.StdIn.readLine()
                         Home

                        if(input2 == 1)
                        {
                             println("Grass Types")
                            // DisplayAllPokemonByType("Grass")

                            
                        }
                        else
                        if(input2 == 2)
                        {
                            println("Fire Types")
                            //DisplayAllPokemonByType("Fire")
                            
                        }
                        else
                        if(input2 == 3)
                        {
                            println("Water Types")
                           // DisplayAllPokemonByType("Water")
                            
                        }
                        else
                        {
                            println("Invalid input")
                            Home

                        }
                         input2 = scala.io.StdIn.readLine()

                    }
                    else
                    if(input2.equalsIgnoreCase("b"))//***********************REGION SUB-MENU*********************
                    {
                       
                        println("All Regions")
                        DisplayAllRegions_Generations
                        println("**************************")
                         input2 = scala.io.StdIn.readLine()
                         Home
                         
                         
                       

                    }
                    else
                    if(input2.equalsIgnoreCase("e"))
                    {
                        Home
                    }
                    else
                    {
                        try
                        {
                            // GetPokemonByNumber(input.toInt)
                            
                        }
                        catch
                        {
                            case e:Exception=>
                           // GetPokemonByName(input)
                        }
                         

                        
                    }




                }


                else 
                if(input_Main.equalsIgnoreCase("2"))//*********************************MAIN MENU OPTION***********************
                {
                    var input3 =""
                    println("Administrator Menu")

                    println("   A) Add a Pokemon to the Pokedex")

                    println("   B) Update a Pokemon currently in the Pokedex")

                    println("   C) Remove a Pokemon from the Pokedex")

                    println("   E) Home")
                    input3 = scala.io.StdIn.readLine()
                    
                    if(input3.equalsIgnoreCase("e"))
                    {
                         
                         Home
                    }
                    else 
                    if(input3.equalsIgnoreCase("a"))//***********************ADD POKEMON SUB-MENU*********************
                    {
                        var input_number = ""
                        var input_name = ""
                        var input_typenumber = ""
                        var input_type2number = ""
                        var input_gennumber = ""
                        var input_Evolves = ""

                        

                        println("Add a new Pokemon to the Pokedex")

                        println("Pokemon ID Number: ")
                        input_number = scala.io.StdIn.readLine()
                        

                        if(input_number != "")
                        {

                        println("Pokemon Name: ")
                        input_name = scala.io.StdIn.readLine()
                        
                            if(input_name != "")
                            {
                                  println("Pokemon TypeID: ")
                                  input_typenumber = scala.io.StdIn.readLine()
                                  
                                      if(input_typenumber != "")
                                      {
                                        println("Pokemon Type2ID: ")
                                        input_type2number = scala.io.StdIn.readLine()
                                       
                                            if(input_type2number != "")
                                            {
                                                 println("Pokemon Generation Number: ")
                                                 input_gennumber = scala.io.StdIn.readLine()
                                                
                                                     if(input_gennumber != "")
                                                     {
                                                        println("Evolves; true/false: ")
                                                        input_Evolves = scala.io.StdIn.readLine()
                                                            if(input_Evolves != "")
                                                            {
                                                                println(input_name +" Has been added to the Pokedex!")
                                                               
                                                               
                                                                AddPokemon(input_number.toInt, input_name, input_typenumber.toInt,
                                                                input_type2number.toInt,input_gennumber.toInt,input_Evolves.toBoolean)

                                                                Home
                                                            }
                                                    }
                                            }
                                      }
                            }

                        }




                    }
                    if(input3.equalsIgnoreCase("b"))//***********************UPDATE POKEMON SUB-MENU*********************
                    {
                        println("Update a Pokemon in the Pokedex")
                                println("   Enter the ID number of the Pokemon you would like to update")

                        var og_number = ""
                        var input_newnumber = ""
                        var input_name = ""
                        var input_typenumber = ""
                        var input_type2number = ""
                        var input_gennumber = ""
                        var input_evolves = ""

                        println("Pokemon ID Number: ")
                        og_number = scala.io.StdIn.readLine()
                        

                        if(og_number != "")
                        {

                            println("Updated Pokemon ID number: ")
                            input_newnumber = scala.io.StdIn.readLine()

                            if(input_newnumber != "")
                            {
                                println("Updated Pokemon Name: ")
                                input_name = scala.io.StdIn.readLine()
                        
                                    if(input_name != "")
                                    {
                                        println("Updated Pokemon TypeID: ")
                                        input_typenumber = scala.io.StdIn.readLine()
                                  
                                            if(input_typenumber != "")
                                            {
                                                println("Updated Pokemon Type2ID: ")
                                                input_type2number = scala.io.StdIn.readLine()
                                       
                                                    if(input_type2number != "")
                                                    {
                                                        println("Updated Pokemon Generation Number: ")
                                                        input_gennumber = scala.io.StdIn.readLine()
                                                
                                                            if(input_gennumber != "")
                                                            {
                                                                println("Evolves: ")
                                                                input_evolves = scala.io.StdIn.readLine()

                                                                    if(input_evolves != "")
                                                                    {
                                                                        println(input_name +" Has been successfully updated!")
                                                               
                                                               //UpdatePokemon(OldID: Int, a: Int, b: String, c: Int, d: Int, e: Int, f: Boolean) 
                                                               
                                                                UpdatePokemon(og_number.toInt, input_newnumber.toInt, input_name, input_typenumber.toInt, input_type2number.toInt, input_gennumber.toInt, input_evolves.toBoolean)

                                                                Home
                                                                    }
                                                            }
                                                    }
                                            }
                                    }

                            }

                        }



                    }
                    else 
                    if(input3.equalsIgnoreCase("c"))//***********************REMOVE POKEMON SUB-MENU*********************
                    {
                        println("Remove a Pokemon from the Pokedex")
                                println("   Enter the ID number of the Pokemon you would like to remove")

                              var input_del = ""

                              input_del = scala.io.StdIn.readLine()

                              if(input_del != "")
                              {
                                println("Are you sure you want to permanently remove this Pokemon from the Pokedex?")
                                println("Y) Yes")
                                println("N) No")

                                var Y_N = ""

                                Y_N = scala.io.StdIn.readLine()

                                if(Y_N.equalsIgnoreCase("y"))
                                {
                                    RemovePokemon(input_del.toInt)
                                    println("Pokemon removed")
                                    Home
                                }
                                else
                                if(Y_N.equalsIgnoreCase("n"))
                                {
                                    println("Pokemon not removed")
                                    Home
                                }


                              }





                    }
                    else
                    {
                        println("Invalid input")
                        Home

                    }
                     



            }
            else
            if(input_Main.equalsIgnoreCase("3"))//*********************************MAIN MENU OPTION***********************
            {
                log.close()
                System.exit(0)
            }
            else
            {
                println("Invalid input")
                Home
                
            }


                        
                     }
                }
                
                



               

        

     
       
    }

