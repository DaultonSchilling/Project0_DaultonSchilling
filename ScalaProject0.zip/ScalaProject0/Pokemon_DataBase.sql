DROP DATABASE Pokemon_DataBase;
CREATE DATABASE Pokemon_DataBase;

Use Pokemon_DataBase;

CREATE TABLE Main 
(
	PokemonID							int					NOT NULL,
	PokemonName							nvarchar(100)		NOT NULL,
	PokemonTypeID                     	int					NOT NULL,
	PokemonType2ID						int				    NOT NULL,
	PokemonGenerationID					int					NOT NULL,
	Evolves								bit				    NOT NULL  DEFAULT 0,
	
	CONSTRAINT pk_PokemonID PRIMARY KEY(PokemonID ASC)

	

);

CREATE TABLE Pokemon_Generation 
(
	PokemonGenerationID						int					NOT NULL,
	PokemonRegionName						nvarchar(100)		NOT NULL,
	
	
	CONSTRAINT pk_PokemonGenerationID PRIMARY KEY(PokemonGenerationID ASC)

);

CREATE TABLE Pokemon_Type 
(
	PokemonTypeID							int					NOT NULL,
	PokemonType								nvarchar(100)		NOT NULL,
	
	
	CONSTRAINT pk_PokemonTypeID PRIMARY KEY(PokemonTypeID ASC)
	
);








INSERT INTO Main 
		(PokemonID, PokemonName , PokemonTypeID, PokemonType2ID, PokemonGenerationID, Evolves)
VALUES 
(1, "Bulbasaur", 1, 0, 1, 1),
(2, "Charmander", 2, 0, 1, 1),
(3, "Squirtle", 3, 0, 1, 1);


INSERT INTO Pokemon_Type  
		(PokemonTypeID, PokemonType)
VALUES 
(1, "Grass"),
(2, "Fire"),
(3, "Water"),
(4, "Poison");





INSERT INTO Pokemon_Generation
		(PokemonGenerationID, PokemonRegionName)
VALUES 
(1, "Kanto"),
(2, "Johto"),
(3, "Hoenn"),
(4, "Sinnoh"),
(5, "Unova"),
(6, "Kalos"),
(7, "Alola"),
(8, "Galar");



SELECT * FROM Main;

SELECT * FROM Pokemon_Generation;

SELECT * FROM Pokemon_Type;





