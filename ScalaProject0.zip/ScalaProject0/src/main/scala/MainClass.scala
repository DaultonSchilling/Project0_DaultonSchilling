import java.sql.DriverManager
import java.sql.Connection
import java.util.Scanner
import java.io.PrintWriter
import java.io.File
import java.util.Calendar


object MainClass
{

    def main(args: Array[String]):Unit = 
    {
//********************************************************************************
    // connect to the database named "mysql" on the localhost
    val driver = "com.mysql.cj.jdbc.Driver"
    // Modify for whatever port you are running your DB on
    val url = "jdbc:mysql://localhost:3306/Pokemon_DataBase" 
    val username = "root"
    val password = "jared24" 
    val log = new PrintWriter(new File("query.log"))

    var connection:Connection = null
//********************************************************************************

    def DisplayAllPokemon: Unit = 
    {
        try 
        {
            Class.forName(driver)
            connection = DriverManager.getConnection(url, username, password)
     
            val statement = connection.createStatement()
            val resultSet = statement.executeQuery("SELECT * FROM Main") 
            log.write(Calendar.getInstance().getTimeInMillis + " - Excecuting 'SELECT * FROM Main'\n")
      
            while ( resultSet.next() )
            {
                 print(resultSet.getInt(1) + " " + resultSet.getString(2))
                 println()
            }

        } 
        catch 
        {
            case e: Exception => e.printStackTrace
            log.write("Error! "+ e.getMessage())
        }
        connection.close()
       
    }

    def DisplayAllRegions_Generations: Unit = 
    {
        try 
        {
            Class.forName(driver)
            connection = DriverManager.getConnection(url, username, password)
     
            val statement = connection.createStatement()
            val resultSet = statement.executeQuery("SELECT * FROM Pokemon_Generation") 
            log.write(Calendar.getInstance().getTimeInMillis + " - Excecuting 'SELECT * FROM Pokemon_Generation'\n")
      
            while ( resultSet.next() )
            {
                 print(resultSet.getInt(1) + " " + resultSet.getString(2))
                 println()
            }

        } 
        catch 
        {
            case e: Exception => e.printStackTrace
            log.write("Error! "+ e.getMessage())
        }
        connection.close()
         
    }

    def DisplayAllTypes: Unit = 
    {
        try 
        {
            Class.forName(driver)
            connection = DriverManager.getConnection(url, username, password)
     
            val statement = connection.createStatement()
            val resultSet = statement.executeQuery("SELECT * FROM Pokemon_Type;") 
            log.write(Calendar.getInstance().getTimeInMillis + " - Excecuting 'SELECT * FROM Pokemon_Type;'\n")
      
            while ( resultSet.next() )
            {
                 print(resultSet.getInt(1) + " " + resultSet.getString(2))
                 println()
            }

        } 
        catch 
        {
            case e: Exception => e.printStackTrace
            log.write("Error! "+ e.getMessage())
        }
        connection.close()
          log.close()
         
    }






   

    def AddPokemon(a: Int, b: String,c: Int,d: Int,e: Int, f:Boolean) 
    {
        Class.forName(driver)
        connection = DriverManager.getConnection(url, username, password)
     
        val statement = connection.createStatement()
        val resultSet = statement.executeQuery("INSERT INTO Pokemon_Generation;") 
        log.write(Calendar.getInstance().getTimeInMillis + " - Excecuting 'sp_insert_Pokemon'\n")

        while (resultSet.next) 
        {
            var id = resultSet.getInt("PokemonID")
            var name = resultSet.getString("PokemonName")
            var typeid = resultSet.getInt("PokemonTypeID")
            var type2id = resultSet.getInt("PokemonType2ID")
            var genid = resultSet.getInt("PokemonGenerationID")
            var evolves = resultSet.getBoolean("Evolves")

            id = a
            name = b
            typeid = c
            type2id = d
            genid = e
            evolves = f

            //AddPokemon(1,"Name",2,3,3,true)

           
        }
         
    }

    
   

//********************************************************************************



        var input_Main = ""

        println("Welcome to the Pokedex! ")
        
        def Home: Unit =
        {

        


        println("A) View Pokedex")
       // println("B) Enter Administrator Menu")
        println("**************************")

        input_Main = scala.io.StdIn.readLine()
        Handler
        }
        
        
        Home
        
       

        def Handler: Unit =
        {
                
                if(input_Main.equalsIgnoreCase("A"))//
                {
                  

                   println("   A) View by Type")
                   println("   B) View by Region/Generation")
                   println("   E) Go Home")
                        
                 //  println("OR Find a Pokemon by typing it's name or number")
                   DisplayAllPokemon
                   println("**************************")
                   
                    var input2 = ""
                    input2 = scala.io.StdIn.readLine()

                   
                   

                    if(input2.equalsIgnoreCase("a"))
                    {
                         DisplayAllTypes
                         println("**************************")

                          
                          input2 = scala.io.StdIn.readLine()
                           Home
                          

                        if(input2 == 1)
                        {
                             println("Grass Types")
                            // DisplayAllPokemonByType("Grass")

                            
                        }
                        else
                        if(input2 == 2)
                        {
                            println("Fire Types")
                            //DisplayAllPokemonByType("Fire")
                            
                        }
                        else
                        if(input2 == 3)
                        {
                            println("Water Types")
                           // DisplayAllPokemonByType("Water")
                            
                        }
                         input2 = scala.io.StdIn.readLine()

                    }
                    else
                    if(input2.equalsIgnoreCase("b"))//
                    {
                       
                        println("All Regions")
                        DisplayAllRegions_Generations
                        println("**************************")
                         input2 = scala.io.StdIn.readLine()
                         Home
                         
                         
                       

                    }
                    else
                    if(input2.equalsIgnoreCase("e"))
                    {
                        Home
                    }
                    else
                    {
                        try
                        {
                            // GetPokemonByNumber(input.toInt)
                            
                        }
                        catch
                        {
                            case e:Exception=>
                           // GetPokemonByName(input)
                        }
                         

                        
                    }




                }


                else 
                if(input_Main.equalsIgnoreCase("B"))
                {
                    var input3 =""
                    println("Administrator Menu")

                    println("   A) Add a Pokemon to the Pokedex")

                    println("   B) Update a Pokemon currently in the Pokedex")

                    println("   C) Remove a Pokemon from the Pokedex")

                    println("   E) Home")
                    input_Main = scala.io.StdIn.readLine()
                    
                    if(input3.equalsIgnoreCase("e"))
                    {
                         
                         Home
                    }
                     else 
                     if(input3.equalsIgnoreCase("a"))
                     {
                        var input_name = ""
                        var input_number = ""
                        var input_typenumber = ""
                        var input_type2number = ""
                        var input_gennumber = ""
                        var input_Evolves = ""

                        println("Add a new Pokemon to the Pokedex")

                        println("Pokemon Name: ")
                        input_name = scala.io.StdIn.readLine()
                        

                        if(input_name != "")
                        {

                        println("Pokemon Number: ")
                        input_number = scala.io.StdIn.readLine()
                        
                            if(input_number != "")
                            {
                                  println("Pokemon TypeID: ")
                                  input_typenumber = scala.io.StdIn.readLine()
                                  
                                      if(input_typenumber != "")
                                      {
                                        println("Pokemon Type2ID: ")
                                        input_type2number = scala.io.StdIn.readLine()
                                       
                                            if(input_type2number != "")
                                            {
                                                 println("Pokemon Generation Number: ")
                                                 input_gennumber = scala.io.StdIn.readLine()
                                                
                                                     if(input_gennumber != "")
                                                     {
                                                        println("Evolves: ")
                                                        input_Evolves = scala.io.StdIn.readLine()
                                                            if(input_Evolves != "")
                                                            {
                                                                println(input_name +" Has been added to the Pokedex!")
                                                                input_Main ="b"
                                                                //Query to add a Pokemon to the Pokedex

                                                            }
                                                    }
                                            }
                                      }
                            }

                        }


                     }
                     else 
                     if(input3.equalsIgnoreCase("b"))
                     {
                        //Query to edit/update a Pokemon in the Pokedex
                     }
                     else 
                     if(input3.equalsIgnoreCase("c"))
                     {
                         var input_id = ""
                         println("Remove a Pokemon from the Pokedex")
                         println("Enter the ID Number of the Pokemon you want to remove")
                         input_id = scala.io.StdIn.readLine()

                         if(input_id != "")
                         {
                           

                            println("Remove this Pokemon from the Pokedex? Y/N")
                            var yn = scala.io.StdIn.readLine()

                                if(yn.equalsIgnoreCase("y"))
                                {
                                    //Query to remove/delete a Pokemon from the Pokedex

                                }
                                else
                                if(yn.equalsIgnoreCase("n"))
                                {
                                    println("Pokemon not removed")
                                    input3 = "b"
                                }
                                else
                                {
                                    println("Invalid Input")
                                    input3 = "b"

                                }



                         }


                        
                     }
                }


                else
                {
                println("Invalid Input")
                Home
                }

        }

       
        Handler
       
    }

}